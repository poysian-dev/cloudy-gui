# Cloudy GUI Preview - Termux build (older, Termux-friendly toolchain)
AGP 8.5.2 / Gradle 8.7 / Kotlin 2.0.21 / compileSdk 34 / JDK 17.
1. termux-setup-storage ; copy this zip to ~ and unzip it (build inside Termux home, NOT /sdcard)
2. bash termux-setup.sh     (once)
3. bash build.sh            (APK -> /sdcard/Download/CloudyGUI.apk)
