#!/data/data/com.termux/files/usr/bin/bash
# One-time setup: Java 17 + Android SDK (cmdline-tools, API 34) + aapt2 override for Termux
set -e
pkg update -y && pkg upgrade -y
pkg install -y openjdk-17 aapt2 wget unzip

export ANDROID_HOME="$HOME/android-sdk"
mkdir -p "$ANDROID_HOME/cmdline-tools"
if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
  cd "$ANDROID_HOME/cmdline-tools"
  wget -O cl.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q cl.zip && mv cmdline-tools latest && rm cl.zip
fi
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKM" --licenses || true
"$SDKM" "platforms;android-34" "build-tools;34.0.0"

mkdir -p "$HOME/.gradle"
touch "$HOME/.gradle/gradle.properties"
grep -q aapt2FromMavenOverride "$HOME/.gradle/gradle.properties" || \
  echo "android.aapt2FromMavenOverride=$PREFIX/bin/aapt2" >> "$HOME/.gradle/gradle.properties"

grep -q ANDROID_HOME "$HOME/.bashrc" 2>/dev/null || echo "export ANDROID_HOME=$ANDROID_HOME" >> "$HOME/.bashrc"
echo "Setup done. Now run:  bash build.sh"
