#!/data/data/com.termux/files/usr/bin/bash
# Build the debug APK and copy it to Download
set -e
cd "$(dirname "$0")"
export ANDROID_HOME="$HOME/android-sdk"
echo "sdk.dir=$ANDROID_HOME" > local.properties
chmod +x gradlew
./gradlew assembleDebug --no-daemon
mkdir -p /sdcard/Download
cp app/build/outputs/apk/debug/app-debug.apk /sdcard/Download/CloudyGUI.apk
echo "APK ready: /sdcard/Download/CloudyGUI.apk"
