// Cloudy GUI preview (GUI-only). UI design based on ZalithLauncher2 (GPL-3.0).
package com.cloudy.gui.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cloudy.gui.R
import com.cloudy.gui.theme.CloudyFont

private const val TOTAL = 6.2f

private fun seg(t: Float, from: Float, to: Float): Float = ((t - from) / (to - from)).coerceIn(0f, 1f)
private fun smooth(x: Float): Float = x * x * (3f - 2f * x)

/**
 * Intro (recreated from the reference clip):
 * logo fades grey->black, "Cloudy" fades in/out, paper background fades in,
 * "Welcome back Cloudy Launcher" fades in, everything fades out. Tap to skip.
 */
@Composable
fun CloudyIntro(modifier: Modifier = Modifier, onFinished: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val finished by rememberUpdatedState(onFinished)

    LaunchedEffect(Unit) {
        progress.animateTo(TOTAL, tween((TOTAL * 1000).toInt(), easing = LinearEasing))
        finished()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer { alpha = 1f - smooth(seg(progress.value, 5.4f, TOTAL)) }
            .background(Color.White)
            .pointerInput(Unit) { detectTapGestures { finished() } },
        contentAlignment = Alignment.Center
    ) {
        Image(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = smooth(seg(progress.value, 2.4f, 3.0f)) },
            painter = painterResource(R.drawable.cloudy_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                modifier = Modifier
                    .width(124.dp)
                    .graphicsLayer {
                        val t = progress.value
                        alpha = smooth(seg(t, 0f, 0.5f))
                        val s = 0.92f + 0.08f * smooth(seg(t, 0f, 0.9f))
                        scaleX = s
                        scaleY = s
                    },
                painter = painterResource(R.drawable.ic_cloudy_logo),
                contentDescription = null,
                contentScale = ContentScale.FillWidth
            )
            Spacer(Modifier.height(10.dp))
            Box(contentAlignment = Alignment.Center) {
                Text(
                    modifier = Modifier.graphicsLayer {
                        val t = progress.value
                        alpha = smooth(seg(t, 0.4f, 0.9f)) * (1f - smooth(seg(t, 2.1f, 2.5f)))
                    },
                    text = "Cloudy",
                    color = Color(0xFF111111),
                    fontFamily = CloudyFont,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp
                )
                Text(
                    modifier = Modifier.graphicsLayer {
                        alpha = smooth(seg(progress.value, 3.2f, 3.7f))
                    },
                    text = "Welcome back Cloudy Launcher",
                    color = Color(0xFF111111),
                    fontFamily = CloudyFont,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp
                )
            }
        }
    }
}
