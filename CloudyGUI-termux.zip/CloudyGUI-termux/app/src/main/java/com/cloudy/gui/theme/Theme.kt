/*
 * Cloudy GUI preview (GUI-only). UI design based on ZalithLauncher2 (GPL-3.0).
 */

package com.cloudy.gui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cloudy.gui.R

val Ink = Color(0xFF1D1D1F)
val InkSoft = Color(0xFF3A3A3C)
val Subtle = Color(0xFF6E6E73)
val Hairline = Color(0xFFD8D8DD)
val Chip = Color(0xFFE8E8ED)
val IosGreen = Color(0xFF34C759)

private val CloudyColors = lightColorScheme(
    primary = Ink, onPrimary = Color.White,
    primaryContainer = Chip, onPrimaryContainer = Ink,
    secondary = InkSoft, onSecondary = Color.White,
    secondaryContainer = Color(0xFFEDEDF2), onSecondaryContainer = Ink,
    tertiary = Color(0xFF007AFF), onTertiary = Color.White,
    background = Color(0xFFF5F5F7), onBackground = Ink,
    surface = Color(0xFFF7F7F9), onSurface = Ink,
    surfaceVariant = Color(0xFFECECF0), onSurfaceVariant = Subtle,
    outline = Color(0xFFAEAEB2), outlineVariant = Hairline,
    error = Color(0xFFFF3B30), onError = Color.White,
)

private val CloudyShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(34.dp),
)

/** Inter (SIL OFL): closest legally-bundleable match to iOS SF Pro. */
val CloudyFont = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

private fun TextStyle.cloudy(tight: Boolean = false) =
    copy(fontFamily = CloudyFont, letterSpacing = if (tight) (-0.2).sp else letterSpacing)

private val base = Typography()
private val CloudyTypography = base.copy(
    displayLarge = base.displayLarge.cloudy(true),
    displayMedium = base.displayMedium.cloudy(true),
    displaySmall = base.displaySmall.cloudy(true),
    headlineLarge = base.headlineLarge.cloudy(true),
    headlineMedium = base.headlineMedium.cloudy(true),
    headlineSmall = base.headlineSmall.cloudy(true),
    titleLarge = base.titleLarge.cloudy(true),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold).cloudy(true),
    titleSmall = base.titleSmall.copy(fontWeight = FontWeight.SemiBold).cloudy(),
    bodyLarge = base.bodyLarge.cloudy(),
    bodyMedium = base.bodyMedium.cloudy(),
    bodySmall = base.bodySmall.cloudy(),
    labelLarge = base.labelLarge.cloudy(),
    labelMedium = base.labelMedium.cloudy(),
    labelSmall = base.labelSmall.cloudy(),
)

@Composable
fun CloudyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CloudyColors,
        shapes = CloudyShapes,
        typography = CloudyTypography,
        content = content
    )
}
