// Cloudy GUI preview (GUI-only). UI design based on ZalithLauncher2 (GPL-3.0).
package com.cloudy.gui.ui

import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.cloudy.gui.R
import com.cloudy.gui.theme.Ink
import com.cloudy.gui.theme.InkSoft
import kotlinx.coroutines.delay

private val IconIdle = Color(0xFF8E8E93)
private val GlowColor = Color(0xFFA9C8FF)

@Immutable
data class DockEntry(
    @DrawableRes val iconRes: Int,
    val label: String,
    val onClick: () -> Unit,
)

/** Raised white "bubble" (light version of the raised button in the reference) */
private fun Modifier.raisedSphere(): Modifier = this
    .shadow(
        elevation = 10.dp,
        shape = CircleShape,
        ambientColor = Color(0x22000000),
        spotColor = Color(0x40000000)
    )
    .background(
        Brush.verticalGradient(listOf(Color.White, Color(0xFFEDEDF2))),
        CircleShape
    )
    .border(
        1.dp,
        Brush.verticalGradient(listOf(Color.White, Color(0x14000000))),
        CircleShape
    )

/**
 * Floating dock: glass capsule + inset groove + ONE raised bubble that glides between items,
 * and a glowing cloud button at the bottom that opens the glass menu.
 */
@Composable
fun CloudyDock(
    modifier: Modifier = Modifier,
    entries: List<DockEntry>,
    selectedIndex: Int,
    onMenuClick: () -> Unit,
) {
    BoxWithConstraints(modifier = modifier.fillMaxHeight()) {
        val count = entries.size + 1
        val gap = 6.dp
        val inner = 8.dp
        val itemSize = ((maxHeight - inner * 2 - 28.dp - gap * (count - 1)) / count).coerceIn(36.dp, 50.dp)
        val width = itemSize + inner * 2 + 8.dp

        Column(
            modifier = Modifier
                .width(width)
                .fillMaxHeight()
                .liquidGlass(RoundedCornerShape(width / 2), tintAlpha = 0.55f)
                .padding(inner),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            //inset groove
            Box(
                modifier = Modifier
                    .background(Color(0x0A000000), RoundedCornerShape(itemSize / 2 + 4.dp))
                    .border(0.8.dp, Color(0x0F000000), RoundedCornerShape(itemSize / 2 + 4.dp))
                    .padding(4.dp)
            ) {
                val bubbleY by animateDpAsState(
                    targetValue = if (selectedIndex >= 0) (itemSize + gap) * selectedIndex else 0.dp,
                    animationSpec = spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow),
                    label = "bubbleY"
                )
                val bubbleAlpha by animateFloatAsState(
                    targetValue = if (selectedIndex >= 0) 1f else 0f,
                    label = "bubbleAlpha"
                )
                Box(
                    modifier = Modifier
                        .offset(y = bubbleY)
                        .size(itemSize)
                        .graphicsLayer { alpha = bubbleAlpha }
                        .raisedSphere()
                )
                Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                    entries.forEachIndexed { i, e -> DockIcon(e, i == selectedIndex, itemSize) }
                }
            }

            CloudButton(size = itemSize + 4.dp, onClick = onMenuClick)
        }
    }
}

@Composable
private fun DockIcon(entry: DockEntry, selected: Boolean, size: Dp) {
    val tint by animateColorAsState(
        targetValue = if (selected) Ink else IconIdle,
        animationSpec = tween(260),
        label = "iconTint"
    )
    Box(
        modifier = Modifier
            .size(size)
            .bouncyClick(entry.onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            modifier = Modifier.size(size * 0.48f),
            painter = painterResource(entry.iconRes),
            contentDescription = entry.label,
            tint = tint
        )
    }
}

@Composable
private fun CloudButton(size: Dp, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "glow")
    val glow by t.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glowPulse"
    )
    Box(
        modifier = Modifier
            .size(size)
            .bouncyClick(onClick)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(GlowColor.copy(alpha = 0.55f * glow), Color.Transparent),
                        radius = this.size.minDimension * 0.95f
                    ),
                    radius = this.size.minDimension * 0.95f
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(2.dp).raisedSphere())
        Icon(
            modifier = Modifier.size(size * 0.52f),
            painter = painterResource(R.drawable.ic_cloudy_logo),
            contentDescription = "Menu",
            tint = Ink
        )
    }
}

/* ------------------------------ Glass pop-up menu ------------------------------ */

@Immutable
data class MenuItem(
    @DrawableRes val iconRes: Int,
    val label: String,
    val danger: Boolean = false,
    val onClick: () -> Unit,
)

/** Pop-up menu that grows out of the cloud button (second reference image) */
@Composable
fun GlassMenu(
    visible: Boolean,
    items: List<MenuItem>,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val origin = TransformOrigin(0f, 1f)
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn(tween(160)) + scaleIn(
            animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow),
            initialScale = 0.82f,
            transformOrigin = origin
        ),
        exit = fadeOut(tween(120)) + scaleOut(
            animationSpec = tween(150),
            targetScale = 0.92f,
            transformOrigin = origin
        )
    ) {
        Column(
            modifier = Modifier
                .width(232.dp)
                .liquidGlass(RoundedCornerShape(28.dp), tintAlpha = 0.74f, elevation = 22.dp)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items.forEachIndexed { i, item -> MenuRow(item, i, onDismiss) }
        }
    }
}

@Composable
private fun MenuRow(item: MenuItem, index: Int, onDismiss: () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val highlight by animateColorAsState(
        targetValue = if (pressed) Color(0x14000000) else Color.Transparent,
        animationSpec = tween(120),
        label = "rowHl"
    )
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(index * 45L)
        shown = true
    }
    val appear by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = tween(320),
        label = "rowAppear"
    )
    val color = if (item.danger) Color(0xFFFF3B30) else InkSoft

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                alpha = appear
                translationX = (1f - appear) * -12.dp.toPx()
            }
            .clip(RoundedCornerShape(20.dp))
            .background(highlight)
            .clickable(interactionSource = source, indication = null) {
                item.onClick()
                onDismiss()
            }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            modifier = Modifier.size(20.dp),
            painter = painterResource(item.iconRes),
            contentDescription = null,
            tint = color
        )
        Text(
            text = item.label,
            style = MaterialTheme.typography.bodyMedium,
            color = if (item.danger) color else Ink
        )
    }
}
