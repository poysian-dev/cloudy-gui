// Cloudy GUI preview (GUI-only). UI design based on ZalithLauncher2 (GPL-3.0).
package com.cloudy.gui.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.cloudy.gui.R
import com.cloudy.gui.theme.Chip
import com.cloudy.gui.theme.Hairline
import com.cloudy.gui.theme.Ink
import com.cloudy.gui.theme.Subtle
import kotlinx.coroutines.delay

enum class Page(val title: String) {
    Home("Cloudy Launcher"),
    Download("Download"),
    Multiplayer("Multiplayer"),
    Files("Files"),
    Settings("Settings"),
}

enum class GameState { None, Loading, Playing }

@Composable
fun CloudyApp() {
    var page by remember { mutableStateOf(Page.Home) }
    var settingsStart by remember { mutableIntStateOf(0) }
    var installing by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var game by remember { mutableStateOf(GameState.None) }
    var introDone by remember { mutableStateOf(false) }

    BackHandler(enabled = menuOpen) { menuOpen = false }
    BackHandler(enabled = !menuOpen && game == GameState.None && page != Page.Home) { page = Page.Home }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.Transparent,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                modifier = Modifier.fillMaxSize(),
                painter = painterResource(R.drawable.cloudy_bg),
                contentDescription = null,
                contentScale = ContentScale.Crop
            )

            Row(modifier = Modifier
                .fillMaxSize()
                .displayCutoutPadding()
            ) {
                CloudyDock(
                    modifier = Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp),
                    entries = listOf(
                        DockEntry(R.drawable.ic_o_home, "Home") { page = Page.Home },
                        DockEntry(R.drawable.ic_o_cube, "Download") { page = Page.Download },
                        DockEntry(R.drawable.ic_o_globe, "Multiplayer") { page = Page.Multiplayer },
                        DockEntry(R.drawable.ic_o_folder, "Files") { page = Page.Files },
                        DockEntry(R.drawable.ic_o_tune, "Settings") { settingsStart = 0; page = Page.Settings },
                    ),
                    selectedIndex = page.ordinal,
                    onMenuClick = { menuOpen = !menuOpen }
                )

                Column(modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                ) {
                    TitleBar(page)
                    AnimatedContent(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        targetState = page,
                        transitionSpec = {
                            (fadeIn(tween(380, delayMillis = 60, easing = CloudyEaseOut)) +
                                    slideInHorizontally(tween(520, easing = CloudyEaseOut)) { it / 14 } +
                                    scaleIn(tween(520, easing = CloudyEaseOut), initialScale = 0.97f)) togetherWith
                                    fadeOut(tween(140))
                        },
                        label = "page"
                    ) { p ->
                        when (p) {
                            Page.Home -> HomePage(onPlay = { game = GameState.Loading })
                            Page.Download -> DownloadPage(onInstall = { installing = true })
                            Page.Multiplayer -> MultiplayerPage()
                            Page.Files -> FilesPage()
                            Page.Settings -> SettingsPage(initialTab = settingsStart)
                        }
                    }
                }
            }

            //click-away scrim + glass menu
            if (menuOpen) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) { detectTapGestures { menuOpen = false } }
                )
            }
            GlassMenu(
                visible = menuOpen,
                onDismiss = { menuOpen = false },
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .displayCutoutPadding()
                    .padding(start = 92.dp, bottom = 14.dp),
                items = listOf(
                    MenuItem(R.drawable.ic_o_person, "Account") { page = Page.Home },
                    MenuItem(R.drawable.ic_o_cube, "Versions") { page = Page.Download },
                    MenuItem(R.drawable.ic_o_folder, "Open folder") { page = Page.Files },
                    MenuItem(R.drawable.ic_o_info, "About") { settingsStart = 3; page = Page.Settings },
                )
            )

            if (installing) LoadingOverlay(onDone = { installing = false })

            //game flow: loading screen -> in-game overlay demo
            AnimatedContent(
                modifier = Modifier.fillMaxSize(),
                targetState = game,
                transitionSpec = { fadeIn(tween(500)) togetherWith fadeOut(tween(400)) },
                label = "game"
            ) { g ->
                when (g) {
                    GameState.None -> Box(Modifier.size(0.dp))
                    GameState.Loading -> GameLoadingScreen(onFinished = { game = GameState.Playing })
                    GameState.Playing -> InGameScreen(onExit = { game = GameState.None })
                }
            }

            if (!introDone) CloudyIntro(onFinished = { introDone = true })
        }
    }
}

@Composable
private fun TitleBar(page: Page) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .padding(start = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Crossfade(targetState = page.title, label = "title") {
            Text(text = it, style = MaterialTheme.typography.titleMedium)
        }
    }
}

private val PagePadding = Modifier.padding(start = 4.dp, end = 12.dp, bottom = 12.dp)

/* ---------------------------------- Home ---------------------------------- */

@Composable
private fun HomePage(onPlay: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxSize()
            .then(PagePadding),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(
            modifier = Modifier
                .weight(1.5f)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            GlassCard(Modifier.fillMaxWidth().weight(1f).cloudyEntrance(0)) { NewsCard() }
            GlassCard(Modifier.fillMaxWidth().weight(1f).cloudyEntrance(1)) { ServersCard() }
        }
        GlassCard(
            modifier = Modifier.weight(1f).fillMaxHeight().cloudyEntrance(2),
            shape = RoundedCornerShape(34.dp)
        ) { ActionCard(onPlay) }
    }
}

@Composable
private fun NewsCard() {
    val news = listOf("Minecraft 1.21.11", "Cloudy 0.1 preview", "Community pack")
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("Latest news", style = MaterialTheme.typography.titleMedium)
        Text("What's new this week", style = MaterialTheme.typography.bodySmall, color = Subtle)
        Spacer(Modifier.height(4.dp))
        Row(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            news.forEach { title ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.White.copy(alpha = 0.7f)),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Text(
                        modifier = Modifier.padding(10.dp),
                        text = title,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }
    }
}

private data class Server(val name: String, val address: String)

@Composable
private fun ServersCard() {
    val servers = listOf(
        Server("PoyzSMP", "play.poyzsmp.net"),
        Server("Hypixel", "mc.hypixel.net"),
        Server("Local world", "Singleplayer"),
    )
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Servers", style = MaterialTheme.typography.titleMedium)
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(servers) { s ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White.copy(alpha = 0.72f))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(Modifier.size(32.dp).clip(CircleShape).background(Chip))
                    Column {
                        Text(s.name, style = MaterialTheme.typography.titleSmall)
                        Text(s.address, style = MaterialTheme.typography.bodySmall, color = Subtle)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionCard(onPlay: () -> Unit) {
    Column(
        modifier = Modifier.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.6f)),
                contentAlignment = Alignment.Center
            ) {
                CloudyFloatingLogo(Modifier.width(64.dp))
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Color.White.copy(alpha = 0.78f))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(Chip))
            Column {
                Text("Steve", style = MaterialTheme.typography.titleSmall)
                Text("Microsoft account", style = MaterialTheme.typography.bodySmall, color = Subtle)
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(26.dp))
                .background(Color.White.copy(alpha = 0.78f))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF78AA5A)))
            Column(Modifier.weight(1f)) {
                Text("1.21.11", style = MaterialTheme.typography.titleSmall)
                Text("Fabric", style = MaterialTheme.typography.bodySmall, color = Subtle)
            }
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .bouncyClick(onPlay)
                    .clip(CircleShape)
                    .background(Ink),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    modifier = Modifier.size(24.dp),
                    painter = painterResource(R.drawable.ic_play_arrow_filled),
                    contentDescription = "Play",
                    tint = Color.White
                )
            }
        }
    }
}

/* ------------------------------- Other pages ------------------------------ */

@Composable
private fun DownloadPage(onInstall: () -> Unit) {
    val versions = listOf("1.21.11" to "Release", "1.21.10" to "Release", "26.1 snapshot" to "Snapshot",
        "1.20.6" to "Release", "1.20.1" to "Release", "1.19.4" to "Release", "1.16.5" to "Release")
    GlassCard(
        modifier = Modifier.fillMaxSize().then(PagePadding).cloudyEntrance(0)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Minecraft versions", style = MaterialTheme.typography.titleMedium)
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(versions) { (name, type) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(Color.White.copy(alpha = 0.72f))
                            .padding(start = 12.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF78AA5A)))
                        Column(Modifier.weight(1f)) {
                            Text(name, style = MaterialTheme.typography.titleSmall)
                            Text(type, style = MaterialTheme.typography.bodySmall, color = Subtle)
                        }
                        PillButton(text = "Install", onClick = onInstall)
                    }
                }
            }
        }
    }
}

@Composable
private fun MultiplayerPage() {
    GlassCard(
        modifier = Modifier.fillMaxSize().then(PagePadding).cloudyEntrance(0)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CloudyFloatingLogo(Modifier.width(84.dp))
            Spacer(Modifier.height(14.dp))
            Text("Play with friends", style = MaterialTheme.typography.titleMedium)
            Text(
                "Create a room or join one with a code",
                style = MaterialTheme.typography.bodySmall,
                color = Subtle
            )
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(text = "Create room", onClick = {})
                PillButton(text = "Join room", onClick = {}, primary = false)
            }
        }
    }
}

@Composable
private fun FilesPage() {
    val folders = listOf("versions", "mods", "resourcepacks", "saves", "screenshots")
    GlassCard(
        modifier = Modifier.fillMaxSize().then(PagePadding).cloudyEntrance(0)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Game folder", style = MaterialTheme.typography.titleMedium)
            Text("/storage/emulated/0/games/Cloudy", style = MaterialTheme.typography.bodySmall, color = Subtle)
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(folders) { f ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.White.copy(alpha = 0.72f))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            modifier = Modifier.size(22.dp),
                            painter = painterResource(R.drawable.ic_folder_filled),
                            contentDescription = null,
                            tint = Ink
                        )
                        Text(f, style = MaterialTheme.typography.titleSmall)
                    }
                }
            }
        }
    }
}

/* ------------------------------ Loading dialog ----------------------------- */

@Composable
private fun LoadingOverlay(onDone: () -> Unit) {
    val tasks = listOf("Checking files", "Preparing runtime", "Loading assets")
    val progress = remember { tasks.map { Animatable(0f) } }
    val pop = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        pop.animateTo(1f, spring(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow))
    }
    LaunchedEffect(Unit) {
        progress.forEach { it.animateTo(1f, tween(1000, easing = LinearOutSlowInEasing)) }
        delay(450)
        onDone()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.22f * pop.value))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        GlassCard(
            modifier = Modifier
                .width(340.dp)
                .graphicsLayer {
                    val s = 0.9f + 0.1f * pop.value
                    scaleX = s
                    scaleY = s
                    alpha = pop.value.coerceIn(0f, 1f)
                },
            shape = RoundedCornerShape(36.dp),
            tintAlpha = 0.9f,
            elevation = 18.dp
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                CloudyFloatingLogo(Modifier.width(64.dp))
                Text("Launching game", style = MaterialTheme.typography.titleMedium)
                tasks.forEachIndexed { i, name -> TaskRow(name, progress[i].value) }
                PillButton(
                    text = "Cancel",
                    onClick = onDone,
                    primary = false,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun TaskRow(name: String, progress: Float) {
    val p = progress.coerceIn(0f, 1f)
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Text(name, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
            Text("${(p * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = Subtle)
        }
        Spacer(Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Hairline)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(p)
                    .fillMaxHeight()
                    .background(Ink)
            )
        }
    }
}
