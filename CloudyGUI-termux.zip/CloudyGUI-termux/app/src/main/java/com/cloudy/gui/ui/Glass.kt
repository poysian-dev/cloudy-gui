/*
 * Cloudy GUI preview (GUI-only). UI design based on ZalithLauncher2 (GPL-3.0).
 */

package com.cloudy.gui.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.cloudy.gui.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** iOS-like ease-out: fast start, very soft landing */
val CloudyEaseOut = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)

/**
 * Liquid Glass: soft shadow + white sheen + top specular + corner glow + edge rim light.
 * (No background blur here; on real Z2 the existing backgroundGlass() adds blur underneath.)
 */
fun Modifier.liquidGlass(
    shape: Shape,
    tintAlpha: Float = 0.62f,
    elevation: Dp = 16.dp,
): Modifier = this
    .shadow(
        elevation = elevation,
        shape = shape,
        ambientColor = Color(0x14000000),
        spotColor = Color(0x26000000)
    )
    .clip(shape)
    .background(Color.White.copy(alpha = tintAlpha))
    .background(
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.80f), Color.White.copy(alpha = 0.48f))
        )
    )
    .drawWithContent {
        drawContent()
        val sheenHeight = size.height * 0.30f
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.White.copy(alpha = 0.55f), Color.Transparent),
                startY = 0f,
                endY = sheenHeight
            ),
            size = Size(size.width, sheenHeight)
        )
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.40f), Color.Transparent),
                center = Offset(size.width * 0.18f, 0f),
                radius = size.maxDimension * 0.55f
            )
        )
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, Color(0x10000000)),
                startY = size.height * 0.72f,
                endY = size.height
            )
        )
        val outline = shape.createOutline(size, layoutDirection, this)
        drawOutline(
            outline = outline,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.95f),
                    Color.White.copy(alpha = 0.10f),
                    Color.White.copy(alpha = 0.65f)
                ),
                start = Offset.Zero,
                end = Offset(size.width, size.height)
            ),
            style = Stroke(width = 2.dp.toPx())
        )
        drawOutline(
            outline = outline,
            color = Color(0x12000000),
            style = Stroke(width = 0.8.dp.toPx())
        )
    }

/** iOS-like press bounce */
@Composable
fun Modifier.bouncyClick(onClick: () -> Unit): Modifier {
    val scale = remember { Animatable(1f) }
    val scope = rememberCoroutineScope()
    val current by rememberUpdatedState(onClick)
    return this
        .graphicsLayer {
            scaleX = scale.value
            scaleY = scale.value
        }
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    scope.launch { scale.animateTo(0.93f, spring(stiffness = Spring.StiffnessMedium)) }
                    tryAwaitRelease()
                    scope.launch {
                        scale.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium))
                    }
                },
                onTap = { current() }
            )
        }
}

/** Staggered entrance: fade + rise + tiny scale */
@Composable
fun Modifier.cloudyEntrance(index: Int = 0): Modifier {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index * 70L)
        p.animateTo(1f, tween(600, easing = CloudyEaseOut))
    }
    return graphicsLayer {
        alpha = p.value
        translationY = (1f - p.value) * 28.dp.toPx()
        val s = 0.97f + 0.03f * p.value
        scaleX = s
        scaleY = s
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(30.dp),
    tintAlpha: Float = 0.62f,
    elevation: Dp = 14.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = modifier
            .then(if (onClick != null) Modifier.bouncyClick(onClick) else Modifier)
            .liquidGlass(shape, tintAlpha, elevation),
        content = content
    )
}

/** Slowly bobbing cloud logo */
@Composable
fun CloudyFloatingLogo(modifier: Modifier = Modifier, amplitude: Float = 5f) {
    val t = rememberInfiniteTransition(label = "float")
    val dy by t.animateFloat(
        initialValue = -amplitude,
        targetValue = amplitude,
        animationSpec = infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "dy"
    )
    Image(
        modifier = modifier.graphicsLayer { translationY = dy.dp.toPx() },
        painter = painterResource(R.drawable.ic_cloudy_logo),
        contentDescription = null,
        contentScale = ContentScale.FillWidth
    )
}
