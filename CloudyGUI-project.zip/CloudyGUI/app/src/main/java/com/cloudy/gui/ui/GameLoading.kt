// Cloudy GUI preview (GUI-only). UI design based on ZalithLauncher2 (GPL-3.0).
package com.cloudy.gui.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.cloudy.gui.R
import com.cloudy.gui.theme.Chip
import com.cloudy.gui.theme.Hairline
import com.cloudy.gui.theme.Ink
import com.cloudy.gui.theme.Subtle
import kotlinx.coroutines.delay

/**
 * "Running Java" screen, redesigned from the reference clip:
 * glass card, cloud inside a spinning arc ring, step text that slides, version chips,
 * progress bar with a moving shine, and a tip line.
 */
@Composable
fun GameLoadingScreen(
    version: String = "Minecraft 26.2",
    startZoom: Float = 1.7f,
    onFinished: () -> Unit,
) {
    //background zooms OUT, then the card pops up with a bounce
    val zoom = remember { Animatable(startZoom) }
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        zoom.animateTo(1f, tween(1100, easing = CloudyEaseOut))
    }
    LaunchedEffect(Unit) {
        delay(450)
        pop.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessLow))
    }

    val steps = listOf("Running Java", "Loading libraries", "Starting Minecraft")
    var step by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        delay(1500); step = 1
        delay(1500); step = 2
        delay(1900); onFinished()
    }

    val t = rememberInfiniteTransition(label = "loading")
    val spin by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)),
        label = "spin"
    )
    val shine by t.animateFloat(
        initialValue = -0.4f, targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing)),
        label = "shine"
    )
    val pulse by t.animateFloat(
        initialValue = 0.95f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val progress by animateFloatAsState(
        targetValue = (step + 1) / 3f * 0.92f,
        animationSpec = tween(900, easing = CloudyEaseOut),
        label = "progress"
    )

    BackdropHost(background = { AppBackground(zoom = { zoom.value }) }) {
        GlassCard(
            modifier = Modifier
                .align(Alignment.Center)
                .width(360.dp)
                .graphicsLayer {
                    val p = pop.value
                    val sc = 0.7f + 0.3f * p
                    scaleX = sc
                    scaleY = sc
                    translationY = (1f - p) * 60.dp.toPx()
                    alpha = p.coerceIn(0f, 1f)
                },
            shape = RoundedCornerShape(40.dp),
            tintAlpha = 0.66f,
            elevation = 22.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 28.dp, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                //spinning ring + cloud
                Box(modifier = Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val stroke = 3.dp.toPx()
                        val inset = stroke
                        val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
                        drawArc(
                            color = Hairline,
                            startAngle = 0f, sweepAngle = 360f, useCenter = false,
                            topLeft = Offset(inset, inset), size = arcSize,
                            style = Stroke(width = stroke)
                        )
                        rotate(spin) {
                            drawArc(
                                brush = Brush.sweepGradient(
                                    listOf(Color.Transparent, Ink.copy(alpha = 0.2f), Ink)
                                ),
                                startAngle = 0f, sweepAngle = 270f, useCenter = false,
                                topLeft = Offset(inset, inset), size = arcSize,
                                style = Stroke(width = stroke, cap = StrokeCap.Round)
                            )
                        }
                    }
                    CloudyFloatingLogo(
                        modifier = Modifier
                            .width(48.dp)
                            .graphicsLayer {
                                scaleX = pulse
                                scaleY = pulse
                            },
                        amplitude = 2.5f
                    )
                }

                //step title (slides up when it changes)
                AnimatedContent(
                    targetState = step,
                    transitionSpec = {
                        (fadeIn(tween(350)) + slideInVertically(tween(450, easing = CloudyEaseOut)) { it / 2 }) togetherWith
                                (fadeOut(tween(200)) + slideOutVertically(tween(300)) { -it / 2 })
                    },
                    label = "stepTitle"
                ) { s ->
                    Text(
                        text = steps[s],
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        textAlign = TextAlign.Center
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoChip(version)
                    InfoChip("Java 21")
                }

                //progress with moving shine
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Hairline)
                ) {
                    val trackWidth = maxWidth
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(progress)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(4.dp))
                            .background(Ink)
                    ) {
                        Box(
                            modifier = Modifier
                                .offset(x = trackWidth * shine)
                                .width(60.dp)
                                .fillMaxHeight()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent)
                                    )
                                )
                        )
                    }
                }

                Spacer(Modifier.height(2.dp))
                Text(
                    text = "Tip: tap the cloud in game to open quick settings",
                    style = MaterialTheme.typography.bodySmall,
                    color = Subtle,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun InfoChip(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Chip)
            .padding(horizontal = 12.dp, vertical = 5.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium)
    }
}
