// Cloudy GUI preview (GUI-only). UI design based on ZalithLauncher2 (GPL-3.0).
package com.cloudy.gui.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.cloudy.gui.R
import com.cloudy.gui.theme.Pal
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** iOS-like ease-out: fast start, very soft landing */
val CloudyEaseOut = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)

/* ------------------------------------------------------------------------------------------
 * Backdrop: the app background is recorded into a GraphicsLayer, a blurred copy is kept in a
 * second layer, and every glass panel draws that blurred copy (slightly magnified, like a lens)
 * clipped to its own shape. This is what makes the glass look like real frosted glass.
 * Blur needs Android 12+ (API 31); on older phones the glass falls back to a plain tint.
 * ---------------------------------------------------------------------------------------- */

class Backdrop(val raw: GraphicsLayer, val blurred: GraphicsLayer)

val LocalBackdrop = compositionLocalOf<Backdrop?> { null }

@Composable
fun BackdropHost(
    modifier: Modifier = Modifier,
    blurRadius: Dp = 26.dp,
    background: @Composable BoxScope.() -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    val raw = rememberGraphicsLayer()
    val blurred = rememberGraphicsLayer()
    val density = LocalDensity.current
    val backdrop = remember(raw, blurred) { Backdrop(raw, blurred) }
    remember(blurred, density, blurRadius) {
        val px = with(density) { blurRadius.toPx() }
        blurred.renderEffect = BlurEffect(px, px, TileMode.Clamp)
        0
    }

    CompositionLocalProvider(LocalBackdrop provides backdrop) {
        Box(modifier = modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawWithContent {
                        raw.record { this@drawWithContent.drawContent() }
                        blurred.record { drawLayer(raw) }
                        drawLayer(raw)
                    },
                content = background
            )
            content()
        }
    }
}

/**
 * Paper background (light) / black waves (dark) + slowly drifting light orbs
 * (gives the glass something to refract). [zoom] scales the whole background.
 */
@Composable
fun AppBackground(modifier: Modifier = Modifier, zoom: () -> Float = { 1f }) {
    val t = rememberInfiniteTransition(label = "orbs")
    val a by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse),
        label = "orbPhase"
    )
    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                val z = zoom()
                scaleX = z
                scaleY = z
            }
    ) {
        Image(
            modifier = Modifier.fillMaxSize(),
            painter = painterResource(R.drawable.cloudy_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop
        )
        Image(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = Pal.t },
            painter = painterResource(R.drawable.cloudy_bg_dark),
            contentDescription = null,
            contentScale = ContentScale.Crop
        )
        Canvas(modifier = Modifier.fillMaxSize()) {
            val k = Pal.t
            fun orb(light: Color, dark: Color, cx: Float, cy: Float, r: Float) {
                val c = lerp(light, dark, k)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(c.copy(alpha = 0.70f - 0.50f * k), Color.Transparent),
                        center = Offset(cx, cy),
                        radius = r
                    ),
                    radius = r,
                    center = Offset(cx, cy)
                )
            }
            val w = size.width
            val h = size.height
            val m = size.minDimension
            orb(Color(0xFFB9D6FF), Color(0xFF3A5FB0), w * (0.16f + 0.12f * a), h * (0.30f + 0.12f * (1 - a)), m * 0.60f)
            orb(Color(0xFFFFC2E6), Color(0xFF8A3E96), w * (0.84f - 0.12f * a), h * (0.26f + 0.16f * a), m * 0.55f)
            orb(Color(0xFFFFE2B5), Color(0xFF2F7A86), w * (0.52f + 0.10f * a), h * (0.88f - 0.10f * a), m * 0.60f)
            orb(Color(0xFFC9F2E0), Color(0xFF4B3C96), w * (0.30f + 0.06f * a), h * (0.78f - 0.08f * a), m * 0.45f)
        }
    }
}

/** 0..1 while the launcher UI slides in from the sides / out of the way (see revealFrom) */
val LocalReveal = compositionLocalOf<() -> Float> { { 1f } }

/**
 * Slides the element in from the left (side = -1) or right (side = +1) and fades it in,
 * driven by [LocalReveal]. [distance] is a multiple of the element's own width.
 */
@Composable
fun Modifier.revealFrom(side: Int, distance: Float): Modifier {
    val reveal = LocalReveal.current
    return graphicsLayer {
        val p = reveal()
        translationX = side * (1f - p) * size.width * distance
        alpha = p.coerceIn(0f, 1f)
    }
}

/**
 * Liquid Glass: blurred+magnified backdrop, tint, top specular, corner glow, inner shade,
 * bright rim light and a soft shadow.
 */
@Composable
fun Modifier.liquidGlass(
    shape: Shape,
    tintAlpha: Float = 0.5f,
    elevation: Dp = 16.dp,
): Modifier {
    val backdrop = LocalBackdrop.current
    var pos by remember { mutableStateOf(Offset.Zero) }
    return this
        .onGloballyPositioned { pos = it.positionInRoot() }
        .shadow(
            elevation = elevation,
            shape = shape,
            ambientColor = Color(0x1A000000),
            spotColor = Color(0x33000000)
        )
        .clip(shape)
        .drawBehind {
            if (backdrop != null) {
                scale(1.06f, 1.06f, pivot = Offset(size.width / 2f, size.height / 2f)) {
                    translate(-pos.x, -pos.y) { drawLayer(backdrop.blurred) }
                }
            }
        }
        .drawBehind {
            val k = Pal.t
            val base = lerp(Color.White, Color(0xFF1A1A20), k)
            val a = (if (backdrop != null) tintAlpha * 0.55f else tintAlpha) * (1f - k) + tintAlpha * 0.9f * k
            drawRect(base.copy(alpha = a))
            val top = 0.55f - 0.43f * k
            val bottom = 0.10f - 0.08f * k
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = top), Color.White.copy(alpha = bottom))
                )
            )
        }
        .drawWithContent {
            drawContent()
            val k = Pal.t
            val sheenHeight = size.height * 0.34f
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color.White.copy(alpha = 0.60f - 0.44f * k), Color.Transparent),
                    startY = 0f,
                    endY = sheenHeight
                ),
                size = Size(size.width, sheenHeight)
            )
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = 0.50f - 0.36f * k), Color.Transparent),
                    center = Offset(size.width * 0.16f, 0f),
                    radius = size.maxDimension * 0.6f
                )
            )
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.08f + 0.20f * k)),
                    startY = size.height * 0.70f,
                    endY = size.height
                )
            )
            val outline = shape.createOutline(size, layoutDirection, this)
            //thick bright rim (top-left light, bottom-right reflection)
            drawOutline(
                outline = outline,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 1f - 0.35f * k),
                        Color.White.copy(alpha = 0.12f - 0.08f * k),
                        Color.White.copy(alpha = 0.80f - 0.45f * k)
                    ),
                    start = Offset.Zero,
                    end = Offset(size.width, size.height)
                ),
                style = Stroke(width = 2.6.dp.toPx())
            )
            //thin hairline so the edge reads on any background
            drawOutline(
                outline = outline,
                color = lerp(Color(0x1F000000), Color(0x26FFFFFF), k),
                style = Stroke(width = 0.8.dp.toPx())
            )
        }
}

/**
 * iOS-like press: the control EXPANDS and gets BRIGHTER while pressed,
 * then springs back with a small overshoot.
 */
@Composable
fun Modifier.bouncyClick(onClick: () -> Unit): Modifier = pressClick(0.10f, onClick)

@Composable
fun Modifier.pressClick(expand: Float, onClick: () -> Unit): Modifier {
    val press = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val current by rememberUpdatedState(onClick)
    return this
        .graphicsLayer {
            val p = press.value
            val s = 1f + expand * p
            scaleX = s
            scaleY = s
            val lift = (p * 46f).coerceIn(0f, 60f)
            colorFilter = if (lift > 0.5f) {
                ColorFilter.colorMatrix(
                    ColorMatrix(
                        floatArrayOf(
                            1f, 0f, 0f, 0f, lift,
                            0f, 1f, 0f, 0f, lift,
                            0f, 0f, 1f, 0f, lift,
                            0f, 0f, 0f, 1f, 0f
                        )
                    )
                )
            } else null
        }
        .pointerInput(Unit) {
            detectTapGestures(
                onPress = {
                    scope.launch {
                        press.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMedium))
                    }
                    tryAwaitRelease()
                    scope.launch {
                        press.animateTo(0f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMediumLow))
                    }
                },
                onTap = { current() }
            )
        }
}

/** Staggered entrance: fade + rise + tiny scale */
@Composable
fun Modifier.cloudyEntrance(index: Int = 0): Modifier {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index * 70L)
        p.animateTo(1f, tween(600, easing = CloudyEaseOut))
    }
    return graphicsLayer {
        alpha = p.value
        translationY = (1f - p.value) * 28.dp.toPx()
        val s = 0.97f + 0.03f * p.value
        scaleX = s
        scaleY = s
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(30.dp),
    tintAlpha: Float = 0.5f,
    elevation: Dp = 14.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = modifier
            .then(if (onClick != null) Modifier.pressClick(0.03f, onClick) else Modifier)
            .liquidGlass(shape, tintAlpha, elevation),
        content = content
    )
}

/** Slowly bobbing cloud logo */
@Composable
fun CloudyFloatingLogo(modifier: Modifier = Modifier, amplitude: Float = 5f) {
    val t = rememberInfiniteTransition(label = "float")
    val dy by t.animateFloat(
        initialValue = -amplitude,
        targetValue = amplitude,
        animationSpec = infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "dy"
    )
    Image(
        modifier = modifier.graphicsLayer { translationY = dy.dp.toPx() },
        painter = painterResource(R.drawable.ic_cloudy_logo),
        contentDescription = null,
        contentScale = ContentScale.FillWidth
    )
}
