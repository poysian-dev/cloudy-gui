// Cloudy GUI preview (GUI-only). UI design based on ZalithLauncher2 (GPL-3.0).
package com.cloudy.gui.ui

import com.cloudy.gui.theme.Ink
import com.cloudy.gui.theme.RowBg
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.cloudy.gui.R
import com.cloudy.gui.theme.Subtle

/**
 * In-game overlay (from the wireframe): dock on the left, settings panel next to it,
 * quick-settings panel on the right, the game stays visible in the middle.
 */
@Composable
fun InGameScreen(onExit: () -> Unit) {
    var overlay by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(1) }

    BackHandler(enabled = overlay) { overlay = false }

    BackdropHost(background = { GameScene() }) {

        //floating cloud (opens the overlay)
        AnimatedVisibility(
            modifier = Modifier
                .align(Alignment.TopStart)
                .displayCutoutPadding()
                .padding(12.dp),
            visible = !overlay,
            enter = fadeIn(tween(300)),
            exit = fadeOut(tween(150))
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .bouncyClick { overlay = true }
                    .liquidGlass(CircleShape, tintAlpha = 0.6f, elevation = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    modifier = Modifier.size(24.dp),
                    painter = painterResource(R.drawable.ic_cloudy_logo),
                    contentDescription = "Open menu",
                    tint = Ink
                )
            }
        }

        //soft scrim
        AnimatedVisibility(visible = overlay, enter = fadeIn(tween(300)), exit = fadeOut(tween(200))) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.14f))
                    .pointerInput(Unit) { detectTapGestures { overlay = false; menuOpen = false } }
            )
        }

        Row(
            modifier = Modifier
                .fillMaxSize()
                .displayCutoutPadding()
                .padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AnimatedVisibility(
                visible = overlay,
                enter = slideInHorizontally(spring(0.8f, Spring.StiffnessMediumLow)) { -it - 40 } + fadeIn(),
                exit = slideOutHorizontally(tween(220)) { -it - 40 } + fadeOut(tween(160))
            ) {
                CloudyDock(
                    entries = listOf(
                        DockEntry(R.drawable.ic_o_home, "Overview") { tab = 0 },
                        DockEntry(R.drawable.ic_o_mouse, "Mouse") { tab = 1 },
                        DockEntry(R.drawable.ic_o_gamepad, "Gamepad") { tab = 2 },
                        DockEntry(R.drawable.ic_o_touch, "Touch") { tab = 3 },
                        DockEntry(R.drawable.ic_o_radar, "Sensors") { tab = 4 },
                    ),
                    selectedIndex = tab,
                    onMenuClick = { menuOpen = !menuOpen },
                    menuOpen = menuOpen
                )
            }

            AnimatedVisibility(
                visible = overlay,
                modifier = Modifier.fillMaxHeight(),
                enter = slideInHorizontally(spring(0.85f, Spring.StiffnessLow)) { -it / 2 } + fadeIn(tween(350)),
                exit = slideOutHorizontally(tween(220)) { -it / 2 } + fadeOut(tween(160))
            ) {
                GlassCard(
                    modifier = Modifier
                        .width(300.dp)
                        .fillMaxHeight(),
                    shape = RoundedCornerShape(34.dp),
                    tintAlpha = 0.7f,
                    elevation = 18.dp
                ) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = {
                            fadeIn(tween(300, delayMillis = 60)) togetherWith fadeOut(tween(120))
                        },
                        label = "panelTab"
                    ) { t -> LeftPanelContent(t) }
                }
            }

            Spacer(Modifier.weight(1f))

            AnimatedVisibility(
                visible = overlay,
                modifier = Modifier.fillMaxHeight(),
                enter = slideInHorizontally(spring(0.85f, Spring.StiffnessLow)) { it / 2 } + fadeIn(tween(350)),
                exit = slideOutHorizontally(tween(220)) { it / 2 } + fadeOut(tween(160))
            ) {
                GlassCard(
                    modifier = Modifier
                        .width(280.dp)
                        .fillMaxHeight(),
                    shape = RoundedCornerShape(34.dp),
                    tintAlpha = 0.7f,
                    elevation = 18.dp
                ) { QuickPanel(onResume = { overlay = false }, onExit = onExit) }
            }
        }

        //menu from the cloud button
        GlassMenu(
            visible = overlay && menuOpen,
            onDismiss = { menuOpen = false },
            modifier = Modifier
                .align(Alignment.TopStart)
                .displayCutoutPadding()
                .padding(start = 92.dp, top = 64.dp),
            items = listOf(
                MenuItem(R.drawable.ic_o_play, "Resume game") { overlay = false },
                MenuItem(R.drawable.ic_o_camera, "Screenshot") { overlay = false },
                MenuItem(R.drawable.ic_o_power, "Exit to launcher", danger = true) { onExit() },
            )
        )
    }
}

@Composable
private fun LeftPanelContent(tab: Int) {
    var sens by remember { mutableFloatStateOf(0.55f) }
    var size by remember { mutableFloatStateOf(0.4f) }
    var smooth by remember { mutableStateOf(true) }
    var tapClick by remember { mutableStateOf(true) }
    var dead by remember { mutableFloatStateOf(0.2f) }
    var rumble by remember { mutableStateOf(true) }
    var btn by remember { mutableFloatStateOf(0.6f) }
    var alpha by remember { mutableFloatStateOf(0.75f) }
    var show by remember { mutableStateOf(true) }
    var gyro by remember { mutableStateOf(false) }
    var gyroSens by remember { mutableFloatStateOf(0.5f) }
    var invert by remember { mutableStateOf(false) }

    val titles = listOf("Overview", "Mouse", "Gamepad", "Touch", "Sensors")
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(titles[tab], style = MaterialTheme.typography.titleMedium)
        when (tab) {
            0 -> {
                InfoLine("Version", "Minecraft 26.2")
                InfoLine("Java", "21")
                InfoLine("Renderer", "Vulkan")
                InfoLine("FPS", "60")
            }
            1 -> {
                SliderRow("Sensitivity", sens, { sens = it })
                SliderRow("Pointer size", size, { size = it })
                SwitchRow("Smoothing", "Softer camera motion", smooth, { smooth = it })
                SwitchRow("Tap to click", null, tapClick, { tapClick = it })
            }
            2 -> {
                SliderRow("Stick deadzone", dead, { dead = it })
                SwitchRow("Vibration", "Controller rumble", rumble, { rumble = it })
                ButtonsRow("Button icons", "Xbox or PlayStation") {
                    PillButton("Xbox", {})
                    PillButton("PS", {}, primary = false)
                }
            }
            3 -> {
                SliderRow("Button size", btn, { btn = it })
                SliderRow("Opacity", alpha, { alpha = it })
                SwitchRow("Show controls", null, show, { show = it })
                ButtonsRow("Layout", "Move and resize buttons") { PillButton("Edit", {}) }
            }
            else -> {
                SwitchRow("Gyroscope", "Aim by tilting the phone", gyro, { gyro = it })
                SliderRow("Sensitivity", gyroSens, { gyroSens = it })
                SwitchRow("Invert Y", null, invert, { invert = it })
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(RowBg, RoundedCornerShape(20.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = Subtle, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
private fun QuickPanel(onResume: () -> Unit, onExit: () -> Unit) {
    var fps by remember { mutableStateOf(true) }
    var volume by remember { mutableFloatStateOf(0.7f) }
    var brightness by remember { mutableFloatStateOf(0.5f) }
    var distance by remember { mutableFloatStateOf(12f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Quick settings", style = MaterialTheme.typography.titleMedium)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SwitchRow("FPS counter", null, fps, { fps = it })
            SliderRow("Volume", volume, { volume = it })
            SliderRow("Brightness", brightness, { brightness = it })
            SliderRow(
                "Render distance", distance, { distance = it },
                valueRange = 4f..32f, format = { "${it.toInt()} chunks" }
            )
        }
        PillButton("Resume", onResume, modifier = Modifier.fillMaxWidth())
        PillButton("Exit game", onExit, primary = false, modifier = Modifier.fillMaxWidth())
    }
}

/** Simple placeholder for the running game (sky, sun, clouds, grass blocks) */
@Composable
private fun GameScene() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF7EB6FF), Color(0xFFCFE6FF)), endY = size.height * 0.62f))
        drawRect(Color(0xFFFFF3A8), topLeft = Offset(size.width * 0.72f, size.height * 0.12f), size = Size(70f, 70f))
        listOf(0.15f to 0.2f, 0.45f to 0.12f, 0.58f to 0.3f).forEach { (x, y) ->
            drawRect(Color.White.copy(alpha = 0.9f), Offset(size.width * x, size.height * y), Size(220f, 50f))
            drawRect(Color.White.copy(alpha = 0.9f), Offset(size.width * x + 40f, size.height * y - 28f), Size(120f, 40f))
        }
        val ground = size.height * 0.62f
        drawRect(Color(0xFF5DA84A), Offset(0f, ground), Size(size.width, 36f))
        drawRect(Color(0xFF8A5A33), Offset(0f, ground + 36f), Size(size.width, size.height - ground - 36f))
        var x = 0f
        while (x < size.width) {
            drawRect(Color(0x22000000), Offset(x, ground), Size(2f, size.height - ground))
            x += 72f
        }
    }
}
