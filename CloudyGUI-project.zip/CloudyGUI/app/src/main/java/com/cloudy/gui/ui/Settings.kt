// Cloudy GUI preview (GUI-only). UI design based on ZalithLauncher2 (GPL-3.0).
package com.cloudy.gui.ui

import com.cloudy.gui.theme.RailSelected
import com.cloudy.gui.theme.RowBgStrong
import com.cloudy.gui.theme.OnInk
import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.cloudy.gui.R
import com.cloudy.gui.theme.Ink
import com.cloudy.gui.theme.Subtle

private enum class Tab(val label: String, @DrawableRes val icon: Int) {
    Appearance("Appearance", R.drawable.ic_o_tune),
    Game("Game", R.drawable.ic_o_gamepad),
    Controls("Controls", R.drawable.ic_o_touch),
    About("About", R.drawable.ic_o_info),
}

@Composable
fun SettingsPage(
    initialTab: Int = 0,
    dark: Boolean = false,
    onDarkChange: (Boolean) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    var tab by remember { mutableIntStateOf(initialTab.coerceIn(0, Tab.entries.size - 1)) }

    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(start = 4.dp, end = 12.dp, bottom = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        GlassCard(
            modifier = Modifier
                .width(176.dp)
                .fillMaxHeight()
                .revealFrom(-1, 1.4f)
                .cloudyEntrance(0),
            shape = RoundedCornerShape(30.dp),
            tintAlpha = 0.58f,
            elevation = 12.dp
        ) {
            Column(
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Tab.entries.forEachIndexed { i, t ->
                    RailItem(t.label, t.icon, selected = i == tab) { tab = i }
                }
            }
        }

        GlassCard(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .revealFrom(1, 0.9f)
                .cloudyEntrance(1),
            shape = RoundedCornerShape(30.dp)
        ) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = { fadeIn(tween(320, delayMillis = 60)) togetherWith fadeOut(tween(120)) },
                label = "settingsTab"
            ) { i ->
                when (Tab.entries[i]) {
                    Tab.Appearance -> AppearanceTab(dark, onDarkChange)
                    Tab.Game -> GameTab()
                    Tab.Controls -> ControlsTab()
                    Tab.About -> AboutTab()
                }
            }
        }
    }
}

/** Selected item = raised white pill (same language as the dock bubble) */
@Composable
private fun RailItem(label: String, @DrawableRes icon: Int, selected: Boolean, onClick: () -> Unit) {
    val sel by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow),
        label = "railSel"
    )
    val tint by animateColorAsState(if (selected) Ink else Color(0xFF8E8E93), tween(240), label = "railTint")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .bouncyClick(onClick)
            .graphicsLayer { shadowElevation = 0f }
            .then(
                if (selected) Modifier.shadow(
                    6.dp, RoundedCornerShape(23.dp),
                    ambientColor = Color(0x22000000), spotColor = Color(0x33000000)
                ) else Modifier
            )
            .clip(RoundedCornerShape(23.dp))
            .background(RailSelected.copy(alpha = RailSelected.alpha * sel))
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            modifier = Modifier.size(22.dp),
            painter = painterResource(icon),
            contentDescription = null,
            tint = tint
        )
        Text(label, style = MaterialTheme.typography.labelLarge, color = tint)
    }
}

@Composable
private fun TabList(title: String, content: @Composable () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text(title, style = MaterialTheme.typography.titleLarge) }
        item { content() }
    }
}

@Composable
private fun AppearanceTab(dark: Boolean, onDarkChange: (Boolean) -> Unit) {
    var anim by remember { mutableStateOf(true) }
    var glass by remember { mutableStateOf(true) }
    var speed by remember { mutableFloatStateOf(1f) }
    var fullscreen by remember { mutableStateOf(false) }
    TabList("Appearance") {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SwitchRow("Black mode", "Dark glass with black waves", dark, onDarkChange)
            SwitchRow("Animations", "Smooth page transitions", anim, { anim = it })
            SwitchRow("Liquid glass", "Bright translucent cards", glass, { glass = it })
            SliderRow(
                "Animation speed", speed, { speed = it },
                valueRange = 0.5f..2f, format = { "${"%.1f".format(it)}×" }
            )
            SwitchRow("Full screen", "Hide system bars", fullscreen, { fullscreen = it })
            ButtonsRow("Updates & files", "Check for a new version or open the data folder") {
                PillButton("Check update", {})
                PillButton("Open folder", {}, primary = false)
            }
        }
    }
}

@Composable
private fun GameTab() {
    var ram by remember { mutableFloatStateOf(3072f) }
    var scale by remember { mutableFloatStateOf(1f) }
    var fps by remember { mutableStateOf(false) }
    var sound by remember { mutableStateOf(true) }
    TabList("Game") {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SliderRow("Memory", ram, { ram = it }, valueRange = 512f..8192f, format = { "${it.toInt()} MB" })
            SliderRow("Resolution", scale, { scale = it }, valueRange = 0.5f..1f, format = { "${(it * 100).toInt()}%" })
            SwitchRow("Show FPS", "Display frame rate in game", fps, { fps = it })
            SwitchRow("Game sound", null, sound, { sound = it })
        }
    }
}

@Composable
private fun ControlsTab() {
    var size by remember { mutableFloatStateOf(0.6f) }
    var opacity by remember { mutableFloatStateOf(0.75f) }
    var haptic by remember { mutableStateOf(true) }
    TabList("Controls") {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SliderRow("Button size", size, { size = it })
            SliderRow("Button opacity", opacity, { opacity = it })
            SwitchRow("Haptic feedback", "Vibrate on press", haptic, { haptic = it })
            ButtonsRow("Layout", "Move and resize on-screen buttons") { PillButton("Edit layout", {}) }
        }
    }
}

@Composable
private fun AboutTab() {
    val uri = LocalUriHandler.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(RowBgStrong)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Image(
                        modifier = Modifier.width(76.dp),
                        painter = painterResource(R.drawable.ic_cloudy_logo),
                        contentDescription = null,
                        contentScale = ContentScale.FillWidth
                    )
                    Column {
                        Text(
                            "Cloudy Launcher",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            "Launcher นี้ถูกดัดแปลง UX/UI โดยคนไทย",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.alpha(0.7f)
                        )
                    }
                }

                Section("สร้างโดย") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NameChip("Pexzy - can")
                        NameChip("Claude AI")
                    }
                }
                Section("เจ้าของ source code") {
                    Text(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { uri.openUri("https://github.com/ZalithLauncher/ZalithLauncher2") }
                            .padding(vertical = 4.dp),
                        text = "https://github.com/ZalithLauncher/ZalithLauncher2.git",
                        style = MaterialTheme.typography.bodyMedium,
                        textDecoration = TextDecoration.Underline
                    )
                }
                Section("แหล่งติดต่อ") {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SelectionContainer {
                            Text("Discord : icankub", style = MaterialTheme.typography.bodyMedium)
                        }
                        Text(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { uri.openUri("https://www.tiktok.com/@Dev.masterkubb") }
                                .padding(vertical = 4.dp),
                            text = "Tiktok : Dev.masterkubb",
                            style = MaterialTheme.typography.bodyMedium,
                            textDecoration = TextDecoration.Underline
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge, color = Subtle)
        content()
    }
}

@Composable
private fun NameChip(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Ink)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(text, color = OnInk, style = MaterialTheme.typography.labelLarge)
    }
}
