# Cloudy GUI Preview (GUI only, no backend)

Standalone Android Studio project with ONLY the new Cloudy UI and fake data.

Build: open in Android Studio and Run, or `./gradlew assembleDebug`
(APK: app/build/outputs/apk/debug/app-debug.apk). GitHub Actions: put this zip at the repo root.

Demo flow: tap Play (home) -> loading screen -> in-game scene -> tap the cloud (top-left).

Glass: ui/Glass.kt (BackdropHost / AppBackground / liquidGlass). Real frosted blur needs Android 12+.
Dock: ui/Dock.kt (primary button colours at the top of the file).
Intro: ui/Intro.kt. Press animation: bouncyClick() in ui/Glass.kt.

Merging into ZalithLauncher2 later: GPL-3.0 - rename the app, show an "unofficial modified version"
notice, keep the original copyright notices.

## Animations / modes
- Launch: intro -> background zooms OUT, dock slides in from the left, panels from the right (ui/App.kt, LocalReveal / revealFrom in ui/Glass.kt).
- Play: UI slides away, background zooms IN, loading screen zooms OUT and the card pops up (ui/GameLoading.kt).
- Black mode: Settings > Appearance > Black mode. Palette lives in theme/Theme.kt (Pal.t blends light/dark).
