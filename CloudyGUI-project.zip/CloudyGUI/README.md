# Cloudy GUI Preview (GUI only, no backend)

Standalone Android Studio project that contains ONLY the new Cloudy UI with fake data,
so you can build and test the look & animations first. Backend (Z2 systems) goes in later.

## Build
1. Install Android Studio (latest), open this folder (CloudyGUI).
2. Let Gradle sync (it asks to install the SDK it needs; accept).
3. Run on a phone (USB debugging) or emulator, or:  `./gradlew assembleDebug`
   APK: app/build/outputs/apk/debug/app-debug.apk
Needs JDK 17+ (Android Studio's built-in JBR is fine). No NDK / Rust needed.

## What is inside (app/src/main/java/com/cloudy/gui)
- theme/Theme.kt      white palette, shapes, Inter font
- ui/Glass.kt         liquidGlass, bouncyClick, entrance animation, floating logo
- ui/Dock.kt          new dock (raised bubble, glow cloud button) + glass pop-up menu
- ui/GameLoading.kt   "Running Java" loading screen
- ui/InGame.kt        in-game overlay (dock + settings panel + quick panel)
- ui/Settings.kt      settings pages + About (credits)
- ui/App.kt           shell, home, download, files, multiplayer pages
- ui/Intro.kt         launch animation
Demo flow: tap Play (home) -> loading screen -> in-game scene -> tap the cloud (top-left).

## Merging into ZalithLauncher2 later
Copy theme/, ui/ into the Z2 module and swap fake data for Z2 ViewModels.
Z2 is GPL-3.0: rename the app (no "ZalithLauncher"/"ZL"), show an "unofficial modified version"
notice on the main screen, keep the original copyright notices.
